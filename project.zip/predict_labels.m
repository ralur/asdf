function [Y_hat] = predict_labels(X_test_bag, test_raw)
    load('train.mat');
    load('validation.mat');
    
    cost_matrix = [0 3 1 2 3; 4 0 2 3 2; 1 2 0 2 1; 2 1 2 0 2; 2 2 2 1 0];
    M = train(Y_train, double(X_train_bag > 0), '-s 7 -c .207');
    [n, ~] = size(X_test_bag);
    [Ys, ~, prob_estimates] = predict(ones(n,1), double(X_test_bag > 0), M, ['-b 1']);
%     costs = cost_matrix * prob_estimates';
%     [~, Y_hat] = min(costs);
%     Y_hat = Y_hat';
    Y_hat = Ys;
end